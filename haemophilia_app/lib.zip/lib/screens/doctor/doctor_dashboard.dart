import 'package:flutter/material.dart';

import '../../models/user_model.dart';
import '../../services/auth_service.dart';
import '../auth/login_screen.dart';

class DoctorDashboard extends StatelessWidget {
  final UserModel user;

  const DoctorDashboard({
    super.key,
    required this.user,
  });

  Future<void> _logout(
    BuildContext context,
  ) async {
    await AuthService().logout();

    if (!context.mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (_) => const LoginScreen(),
      ),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            const Text('Doctor Dashboard'),
        actions: [
          IconButton(
            tooltip: 'Logout',
            onPressed: () =>
                _logout(context),
            icon:
                const Icon(Icons.logout),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints:
                const BoxConstraints(
              maxWidth: 1200,
            ),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome, Dr. ${user.name}',
                  style: const TextStyle(
                    fontSize: 30,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 8),

                const Text(
                  'Monitor patient physiotherapy progress.',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                  ),
                ),

                const SizedBox(height: 30),

                Row(
                  children: [
                    _statCard(
                      'Patients',
                      '0',
                      Icons.people,
                    ),
                    const SizedBox(width: 16),
                    _statCard(
                      'Assessments',
                      '0',
                      Icons.analytics,
                    ),
                    const SizedBox(width: 16),
                    _statCard(
                      'Average Score',
                      '—',
                      Icons.trending_up,
                    ),
                  ],
                ),

                const SizedBox(height: 35),

                const Text(
                  'Patient Monitoring',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 14),

                const Card(
                  child: ListTile(
                    leading:
                        CircleAvatar(
                      child:
                          Icon(Icons.person),
                    ),
                    title: Text(
                      'No patients assigned',
                    ),
                    subtitle: Text(
                      'Assigned patients will appear here.',
                    ),
                  ),
                ),

                const SizedBox(height: 35),

                const Text(
                  'Analytics',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 14),

                Row(
                  children: [
                    Expanded(
                      child:
                          _analyticsCard(
                        Icons.show_chart,
                        'Score Progress',
                        'Patient score over time',
                      ),
                    ),
                    const SizedBox(
                      width: 16,
                    ),
                    Expanded(
                      child:
                          _analyticsCard(
                        Icons.timeline,
                        'ROM Progress',
                        'Range of motion over time',
                      ),
                    ),
                    const SizedBox(
                      width: 16,
                    ),
                    Expanded(
                      child:
                          _analyticsCard(
                        Icons.bar_chart,
                        'Movement Errors',
                        'Recurring form errors',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _statCard(
    String title,
    String value,
    IconData icon,
  ) {
    return Expanded(
      child: Card(
        child: Padding(
          padding:
              const EdgeInsets.all(20),
          child: Column(
            children: [
              Icon(
                icon,
                size: 32,
                color: Colors.blue,
              ),
              const SizedBox(height: 10),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 25,
                  fontWeight:
                      FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                title,
                textAlign:
                    TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _analyticsCard(
    IconData icon,
    String title,
    String subtitle,
  ) {
    return Card(
      child: Padding(
        padding:
            const EdgeInsets.all(22),
        child: Column(
          children: [
            Icon(
              icon,
              size: 40,
              color: Colors.blue,
            ),
            const SizedBox(height: 14),
            Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight:
                    FontWeight.bold,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              subtitle,
              textAlign:
                  TextAlign.center,
              style: const TextStyle(
                color: Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }
}