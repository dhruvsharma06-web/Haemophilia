import 'package:flutter/material.dart';

import '../../models/user_model.dart';
import '../../services/auth_service.dart';
import '../auth/login_screen.dart';
import 'live_assessment_screen.dart';

class PatientDashboard extends StatefulWidget {
  final UserModel user;

  const PatientDashboard({
    super.key,
    required this.user,
  });

  @override
  State<PatientDashboard> createState() =>
      _PatientDashboardState();
}

class _PatientDashboardState
    extends State<PatientDashboard> {
  final AuthService _authService = AuthService();

  Future<void> _logout() async {
    await _authService.logout();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (_) => const LoginScreen(),
      ),
      (route) => false,
    );
  }

  void _startAssistedFlexion() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const LiveAssessmentScreen(
          exerciseName: 'Assisted Shoulder Flexion',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Patient Dashboard'),
        actions: [
          IconButton(
            tooltip: 'Logout',
            onPressed: _logout,
            icon: const Icon(Icons.logout),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            24,
            28,
            24,
            40,
          ),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(
                maxWidth: 1500,
              ),
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(
                    'Welcome, ${widget.user.name}',
                    style: const TextStyle(
                      fontSize: 40,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Track your physiotherapy progress and assessments.',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.grey,
                    ),
                  ),
                  const SizedBox(height: 42),

                  // --------------------------------------------------
                  // STAT CARDS
                  // --------------------------------------------------

                  LayoutBuilder(
                    builder: (
                      context,
                      constraints,
                    ) {
                      if (constraints.maxWidth < 750) {
                        return Column(
                          children: [
                            _StatCard(
                              icon: Icons
                                  .analytics_outlined,
                              value: '—',
                              label: 'Latest Score',
                            ),
                            const SizedBox(height: 16),
                            _StatCard(
                              icon: Icons
                                  .bar_chart_outlined,
                              value: '0',
                              label: 'Assessments',
                            ),
                            const SizedBox(height: 16),
                            _StatCard(
                              icon: Icons.check_circle,
                              value: '—',
                              label: 'Correct Reps',
                            ),
                          ],
                        );
                      }

                      return Row(
                        children: [
                          Expanded(
                            child: _StatCard(
                              icon: Icons
                                  .analytics_outlined,
                              value: '—',
                              label: 'Latest Score',
                            ),
                          ),
                          const SizedBox(width: 24),
                          Expanded(
                            child: _StatCard(
                              icon: Icons
                                  .bar_chart_outlined,
                              value: '0',
                              label: 'Assessments',
                            ),
                          ),
                          const SizedBox(width: 24),
                          Expanded(
                            child: _StatCard(
                              icon: Icons.check_circle,
                              value: '—',
                              label: 'Correct Reps',
                            ),
                          ),
                        ],
                      );
                    },
                  ),

                  const SizedBox(height: 48),

                  // --------------------------------------------------
                  // EXERCISES
                  // --------------------------------------------------

                  const Text(
                    'Exercises',
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Assisted Shoulder Flexion
                  _ExerciseCard(
                    icon: Icons.accessibility_new,
                    title: 'Assisted Shoulder Flexion',
                    subtitle:
                        'AI-powered movement assessment',
                    enabled: true,
                    buttonText: 'Start',
                    onPressed:
                        _startAssistedFlexion,
                  ),

                  const SizedBox(height: 20),

                  // Shoulder Rotation
                  _ExerciseCard(
                    icon: Icons.rotate_right,
                    title: 'Shoulder Rotation',
                    subtitle: 'Coming soon',
                    enabled: false,
                    buttonText: 'Unavailable',
                    onPressed: null,
                  ),

                  const SizedBox(height: 48),

                  // --------------------------------------------------
                  // RECENT ASSESSMENTS
                  // --------------------------------------------------

                  const Text(
                    'Recent Assessments',
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 20),

                  Card(
                    elevation: 1,
                    child: Padding(
                      padding:
                          const EdgeInsets.all(28),
                      child: Center(
                        child: Column(
                          children: [
                            Icon(
                              Icons
                                  .history_outlined,
                              size: 52,
                              color: Colors.grey
                                  .shade500,
                            ),
                            const SizedBox(height: 14),
                            const Text(
                              'No assessments yet',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight:
                                    FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Complete your first assessment to see your results here.',
                              textAlign:
                                  TextAlign.center,
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors
                                    .grey.shade600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 32),

                  // --------------------------------------------------
                  // ACCOUNT INFORMATION
                  // --------------------------------------------------

                  Card(
                    elevation: 1,
                    child: Padding(
                      padding:
                          const EdgeInsets.all(24),
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 28,
                            child: Text(
                              widget.user.name.isNotEmpty
                                  ? widget.user.name[0]
                                      .toUpperCase()
                                  : 'P',
                              style:
                                  const TextStyle(
                                fontSize: 22,
                                fontWeight:
                                    FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment
                                      .start,
                              children: [
                                Text(
                                  widget.user.name,
                                  style:
                                      const TextStyle(
                                    fontSize: 18,
                                    fontWeight:
                                        FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(
                                  height: 4,
                                ),
                                Text(
                                  widget.user.email,
                                  style:
                                      const TextStyle(
                                    color: Colors.grey,
                                  ),
                                ),
                                const SizedBox(
                                  height: 4,
                                ),
                                const Text(
                                  'Patient Account',
                                  style:
                                      TextStyle(
                                    color: Colors.blue,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ================================================================
// STAT CARD
// ================================================================

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;

  const _StatCard({
    required this.icon,
    required this.value,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 1,
      child: SizedBox(
        height: 190,
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment:
                MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 42,
                color: Colors.blue,
              ),
              const SizedBox(height: 18),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 38,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 18,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ================================================================
// EXERCISE CARD
// ================================================================

class _ExerciseCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool enabled;
  final String buttonText;
  final VoidCallback? onPressed;

  const _ExerciseCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.enabled,
    required this.buttonText,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 30,
          vertical: 26,
        ),
        child: Row(
          children: [
            Container(
              width: 68,
              height: 68,
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                size: 34,
                color: Colors.blue.shade700,
              ),
            ),
            const SizedBox(width: 24),
            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 17,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 20),
            SizedBox(
              height: 50,
              child: enabled
                  ? FilledButton(
                      onPressed: onPressed,
                      child: Padding(
                        padding:
                            const EdgeInsets.symmetric(
                          horizontal: 24,
                        ),
                        child: Text(
                          buttonText,
                          style:
                              const TextStyle(
                            fontSize: 16,
                          ),
                        ),
                      ),
                    )
                  : OutlinedButton(
                      onPressed: null,
                      child: Padding(
                        padding:
                            const EdgeInsets.symmetric(
                          horizontal: 18,
                        ),
                        child: Text(
                          buttonText,
                          style:
                              const TextStyle(
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}