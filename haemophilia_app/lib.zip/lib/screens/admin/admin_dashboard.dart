import 'package:flutter/material.dart';

import '../../models/user_model.dart';
import '../../services/auth_service.dart';
import '../auth/login_screen.dart';

class AdminDashboard extends StatelessWidget {
  final UserModel user;

  const AdminDashboard({
    super.key,
    required this.user,
  });

  Future<void> _logout(
    BuildContext context,
  ) async {
    await AuthService().logout();

    if (!context.mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (_) => const LoginScreen(),
      ),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            const Text('Admin Dashboard'),
        actions: [
          IconButton(
            tooltip: 'Logout',
            onPressed: () =>
                _logout(context),
            icon:
                const Icon(Icons.logout),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints:
                const BoxConstraints(
              maxWidth: 1100,
            ),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome, ${user.name}',
                  style: const TextStyle(
                    fontSize: 30,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 8),

                const Text(
                  'Manage the physiotherapy platform.',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                  ),
                ),

                const SizedBox(height: 30),

                Row(
                  children: [
                    _statCard(
                      'Doctors',
                      '0',
                      Icons.medical_services,
                    ),
                    const SizedBox(width: 16),
                    _statCard(
                      'Patients',
                      '0',
                      Icons.people,
                    ),
                    const SizedBox(width: 16),
                    _statCard(
                      'Assessments',
                      '0',
                      Icons.analytics,
                    ),
                  ],
                ),

                const SizedBox(height: 35),

                const Text(
                  'Administration',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 14),

                Card(
                  child: Column(
                    children: [
                      _adminAction(
                        Icons.medical_services,
                        'Manage Doctors',
                        'Add, edit and manage doctor accounts.',
                      ),
                      const Divider(height: 1),
                      _adminAction(
                        Icons.people,
                        'Manage Patients',
                        'View and manage patient accounts.',
                      ),
                      const Divider(height: 1),
                      _adminAction(
                        Icons.assignment_ind,
                        'Assign Patients',
                        'Assign patients to doctors.',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _statCard(
    String title,
    String value,
    IconData icon,
  ) {
    return Expanded(
      child: Card(
        child: Padding(
          padding:
              const EdgeInsets.all(20),
          child: Column(
            children: [
              Icon(
                icon,
                size: 32,
                color: Colors.blue,
              ),
              const SizedBox(height: 10),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 25,
                  fontWeight:
                      FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                title,
                textAlign:
                    TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _adminAction(
    IconData icon,
    String title,
    String subtitle,
  ) {
    return ListTile(
      contentPadding:
          const EdgeInsets.all(18),
      leading: CircleAvatar(
        child: Icon(icon),
      ),
      title: Text(
        title,
        style: const TextStyle(
          fontWeight:
              FontWeight.bold,
        ),
      ),
      subtitle: Text(subtitle),
      trailing: const Icon(
        Icons.arrow_forward_ios,
        size: 18,
      ),
      onTap: () {
        // Management screens
        // will be added later.
      },
    );
  }
}