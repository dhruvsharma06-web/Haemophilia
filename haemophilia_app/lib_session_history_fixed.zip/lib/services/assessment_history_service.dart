import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AssessmentHistoryService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String? get currentUserId => _auth.currentUser?.uid;

  CollectionReference<Map<String, dynamic>> _collection(String uid) {
    return _firestore.collection('users').doc(uid).collection('assessments');
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchAssessments() {
    final uid = _auth.currentUser?.uid;
    if (uid == null) {
      return Stream<QuerySnapshot<Map<String, dynamic>>>.empty();
    }

    return _collection(uid)
        .orderBy('createdAt', descending: true)
        .limit(100)
        .snapshots();
  }

  Future<void> saveCompletedRep({
    required String exercise,
    required String sessionId,
    required Map<String, dynamic> rep,
  }) async {
    final user = _auth.currentUser;
    if (user == null) {
      throw StateError('No authenticated Firebase user is available.');
    }

    final uid = user.uid;
    final now = Timestamp.now();

    final data = <String, dynamic>{
      'exercise': exercise,
      'sessionId': sessionId,
      'form': rep['form']?.toString() ?? rep['label']?.toString() ?? 'Unknown',
      'repNumber': _number(rep['rep_number'])?.toInt(),
      'score': _number(rep['score']),
      'rangeOfMotion': _number(rep['range_of_motion'] ?? rep['rom']),
      'duration': _number(rep['duration']),
      'speed': rep['speed']?.toString() ?? 'Unknown',
      'smoothness': _number(rep['smoothness_raw'] ?? rep['smoothness']),
      'confidence': _number(rep['confidence'] ?? rep['lstm_confidence']),
      'errorType': rep['error_type']?.toString() ?? rep['error']?.toString() ?? '',
      'feedback': rep['feedback']?.toString() ?? '',
      'errorFramePath': rep['error_frame_path']?.toString() ?? '',
      'createdAt': now,
      'createdAtMillis': DateTime.now().millisecondsSinceEpoch,
    };

    final document = await _collection(uid).add(data);
    print(
      'Assessment history saved: users/$uid/assessments/${document.id} '
      '(session: $sessionId)',
    );
  }

  double? _number(dynamic value) {
    if (value is num) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }
}
