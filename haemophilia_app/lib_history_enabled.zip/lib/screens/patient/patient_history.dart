import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../services/assessment_history_service.dart';

class PatientHistory extends StatelessWidget {
  const PatientHistory({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Assessment history',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      body: SafeArea(
        child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: AssessmentHistoryService().watchAssessments(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting &&
                !snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    'Could not load your assessment history.\n\n${snapshot.error}',
                    textAlign: TextAlign.center,
                  ),
                ),
              );
            }

            final docs = snapshot.data?.docs ?? const [];
            if (docs.isEmpty) {
              return const _HistoryEmptyState();
            }

            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
              itemCount: docs.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                return _HistoryCard(data: docs[index].data());
              },
            );
          },
        ),
      ),
    );
  }
}

class _HistoryCard extends StatelessWidget {
  final Map<String, dynamic> data;

  const _HistoryCard({required this.data});

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final form = data['form']?.toString() ?? 'Unknown';
    final incorrect = form.toLowerCase().contains('incorrect');
    final score = _number(data['score']);
    final rom = _number(data['rangeOfMotion']);
    final duration = _number(data['duration']);
    final speed = data['speed']?.toString() ?? 'Unknown';
    final confidence = _number(data['confidence']);
    final exercise = data['exercise']?.toString() ?? 'Assessment';
    final error = data['errorType']?.toString() ?? '';
    final feedback = data['feedback']?.toString() ?? '';
    final createdAt = data['createdAt'];
    final date = createdAt is Timestamp ? _formatDateTime(createdAt.toDate()) : 'Recent';

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: (incorrect ? Colors.red : primary).withValues(alpha: .09),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(
                    incorrect ? Icons.warning_amber_rounded : Icons.check_circle_outline,
                    color: incorrect ? Colors.red.shade600 : primary,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(exercise, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                      const SizedBox(height: 3),
                      Text(date, style: TextStyle(color: Colors.grey.shade600, fontSize: 11.5)),
                    ],
                  ),
                ),
                Text(
                  '${score.toStringAsFixed(0)}/100',
                  style: TextStyle(
                    color: incorrect ? Colors.red.shade700 : primary,
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                _Metric(label: 'FORM', value: form),
                _Metric(label: 'ROM', value: '${rom.toStringAsFixed(0)}°'),
                _Metric(label: 'SPEED', value: speed),
                _Metric(label: 'DURATION', value: '${duration.toStringAsFixed(1)}s'),
              ],
            ),
            if (confidence > 0 || error.isNotEmpty || feedback.isNotEmpty) ...[
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  color: Colors.grey.withValues(alpha: .06),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (error.isNotEmpty)
                      Text(
                        error.replaceAll('_', ' ').toUpperCase(),
                        style: TextStyle(color: Colors.red.shade700, fontWeight: FontWeight.w800, fontSize: 11),
                      ),
                    if (feedback.isNotEmpty) ...[
                      if (error.isNotEmpty) const SizedBox(height: 3),
                      Text(feedback, style: TextStyle(color: Colors.grey.shade700, fontSize: 12, height: 1.35)),
                    ],
                    if (confidence > 0) ...[
                      const SizedBox(height: 5),
                      Text('AI confidence: ${confidence.toStringAsFixed(1)}%', style: TextStyle(color: Colors.grey.shade600, fontSize: 10.5)),
                    ],
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  final String label;
  final String value;
  const _Metric({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(color: Colors.grey.shade500, fontSize: 9, fontWeight: FontWeight.w800)),
          const SizedBox(height: 3),
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _HistoryEmptyState extends StatelessWidget {
  const _HistoryEmptyState();

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(color: primary.withValues(alpha: .08), shape: BoxShape.circle),
              child: Icon(Icons.history_rounded, size: 36, color: primary),
            ),
            const SizedBox(height: 16),
            const Text('No assessments yet', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 7),
            Text(
              'Complete your first assessment and your results will appear here.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey.shade600, fontSize: 14, height: 1.4),
            ),
          ],
        ),
      ),
    );
  }
}

double _number(dynamic value) {
  if (value is num) return value.toDouble();
  return double.tryParse(value?.toString() ?? '') ?? 0;
}

String _formatDateTime(DateTime date) {
  final local = date.toLocal();
  final now = DateTime.now();
  final time = '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
  if (local.year == now.year && local.month == now.month && local.day == now.day) {
    return 'Today • $time';
  }
  return '${local.day.toString().padLeft(2, '0')}/${local.month.toString().padLeft(2, '0')}/${local.year} • $time';
}
